import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class SimpleQuizGame extends JFrame implements ActionListener {

    String[] questions = { 
            "What is the correct file extension for a Java source file?",
            "Which of the following is a valid declaration of a variable in Java?",
            "What is the output of the following code? System.out.println(5 + 3 + \"Java\");",
            "Which of the following is not a Java primitive type?",
            "What keyword is used to create a subclass in Java?"
    };

    String[][] options = {
            {".jav", ".java", ".class", ".js"},
            {" int 1x = 10;", "int x = 10;", " float x = \"10\"", " double x = (10);"},
            {"8Java", "Java8", "53Java", " 5 + 3Java"},
            {"int", "Float", "String", " boolean"},
            {"implements", "extends", "inherits", " includes"},
    };

    int[] correctAnswers = {1, 1, 0, 1, 2}; 
    int currentQuestionIndex = 0; 
    int score = 0;

    JLabel questionLabel;
    JRadioButton[] optionButtons;
    ButtonGroup optionsGroup;
    JButton nextButton;
    JLabel scoreLabel;
    JPanel optionsPanel;
    JPanel scorePanel;
    JPanel startPanel;
    JPanel quizPanel;

    public SimpleQuizGame() {
        setTitle("Simple Quiz Game");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new CardLayout());  

        startPanel = new JPanel();
        startPanel.setLayout(new BorderLayout());
        addStartPanel();

        quizPanel = new JPanel();
        quizPanel.setLayout(new BorderLayout());
        addQuizPanel();

        add(startPanel); 
        add(quizPanel);   

        setVisible(true);
    }

    private void addStartPanel() {
        JLabel bannerLabel = new JLabel();
        bannerLabel.setHorizontalAlignment(JLabel.CENTER);
        
        ImageIcon bannerIcon = new ImageIcon("q.jpg");  
        Image scaledBannerImage = bannerIcon.getImage().getScaledInstance(400, 150, Image.SCALE_SMOOTH);
        bannerLabel.setIcon(new ImageIcon(scaledBannerImage));
        
        startPanel.add(bannerLabel, BorderLayout.CENTER);

        JButton startButton = new JButton("Start Quiz");
        startButton.addActionListener(e -> switchToQuizPanel());
        startPanel.add(startButton, BorderLayout.SOUTH);
    }

    private void addQuizPanel() {
        questionLabel = new JLabel(questions[currentQuestionIndex]);
        quizPanel.add(questionLabel, BorderLayout.NORTH);

        optionsPanel = new JPanel();
        optionsPanel.setLayout(new BoxLayout(optionsPanel, BoxLayout.Y_AXIS));
        quizPanel.add(optionsPanel, BorderLayout.CENTER);

        optionButtons = new JRadioButton[4];
        optionsGroup = new ButtonGroup();
        for (int i = 0; i < 4; i++) {
            optionButtons[i] = new JRadioButton(options[currentQuestionIndex][i]);
            optionButtons[i].setActionCommand(String.valueOf(i));
            optionsGroup.add(optionButtons[i]);
            optionsPanel.add(optionButtons[i]);
        }

        scorePanel = new JPanel();
        scorePanel.setLayout(new FlowLayout());
        scoreLabel = new JLabel("Score: 0/" + questions.length);
        scorePanel.add(scoreLabel);
        quizPanel.add(scorePanel, BorderLayout.SOUTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout());
        nextButton = new JButton("Next");
        nextButton.addActionListener(this);
        buttonPanel.add(nextButton);

        quizPanel.add(buttonPanel, BorderLayout.PAGE_END);
    }
  
    private void switchToQuizPanel() {
        startPanel.setVisible(false);  
        quizPanel.setVisible(true);    
        updateQuestion();  
    }

    private void updateQuestion() {
        if (currentQuestionIndex < questions.length) {
            questionLabel.setText(questions[currentQuestionIndex]);

            for (int i = 0; i < 4; i++) {
                optionButtons[i].setText(options[currentQuestionIndex][i]);
                optionButtons[i].setSelected(false); 
            }
        } else {
            JOptionPane.showMessageDialog(this, "Quiz Over! Your final score is: " + score + "/" + questions.length);
            System.exit(0); 
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (optionsGroup.getSelection() != null) {
            String selectedOption = optionsGroup.getSelection().getActionCommand();
            int selectedAnswer = Integer.parseInt(selectedOption);
    
            if (selectedAnswer == correctAnswers[currentQuestionIndex]) {
                score++;
            }
    
            currentQuestionIndex++;
            scoreLabel.setText("Score: " + score + "/" + questions.length);
            updateQuestion();
        }
    }

    public static void main(String[] args) {
        new SimpleQuizGame();
    }
}
